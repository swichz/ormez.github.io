<?php
$customCSS = array('<link href="../assets/plugins/DataTables/datatables.min.css" rel="stylesheet">');
$customJAVA = array(
    '<script src="../assets/plugins/DataTables/datatables.min.js"></script>',
    '<script src="../assets/plugins/printer/main.js"></script>',
    '<script src="../assets/js/pages/datatables.js"></script>',
    '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.3.0/dist/sweetalert2.all.min.js"></script>',
    '<script src="../assets/plugins/jquery.toast/jquery.toast.js"></script>'

);

$page_title = 'Ad Soyad';
include('inc/header_main.php');
include('inc/header_sidebar.php');
include('inc/header_native.php');

error_reporting(0);

?>
<!--<div class="page-content">-->
<!--BAŞLANGIC-->
<div class="row">
    <div class="col-xl-12 col-md-6">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">
                        Ad Soyad
					</h4>
                    <p>Sorgulanacak Kişinin Ad Soyadını Giriniz.</p>
                    <div class="block-content tab-content">
                        <div class="tab-pane active" id="tc" role="tabpanel">
                            <input require maxlength="11" class="form-control" type="text" name="first" id="first"
                                placeholder="Ad"><br>
                            <input require maxlength="11" class="form-control" type="text" name="last" id="last"
                                placeholder="Soyad"><br>
                            <center>
                                <button onclick="checkNumber()" id="sorgula"
                                    class="btn waves-effect waves-light btn-rounded btn-success"
                                    style="width: 180px; height: 45px; outline: none; margin-left: 5px;">
                                    <i class="fas fa-search"></i> Sorgula </button>
                                <button onclick="clearResults()" id="durdurButon"
                                    class="btn waves-effect waves-light btn-rounded btn-danger"
                                    style="width: 180px; height: 45px; outline: none; margin-left: 5px;">
                                    <i class="fas fa-trash-alt"></i> Sıfırla </button>
                            </center>
                            <div class="table-responsive">
                                <table id="zero-conf" class="table table-hover" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>T.C</th>
                                            <th>ADI</th>
                                            <th>SOYADI</th>
                                            <th>ANNE ADI</th>
                                            <th>BABA ADI</th>
											<th>DOGUM YERI</th>
											<th>DOGUM TARIHI</th>
											<th>ADRES</th>
                                        </tr>
                                    </thead>
                                    <tbody id="jojjoojj">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function clearResults() {

        $("#jojjoojj").html(
            '<tr class="odd"><td valign="top" colspan="21" class="dataTables_empty">No data available in table</td></tr>'
        );

        $("#first").val("");
        $("#last").val("");
    }

    function checkNumber() {


		var roleNumber = "<?= $k_rol ?>";

        if (parseInt(roleNumber) == 1 || parseInt(roleNumber) == 2) {

            $.Toast.showToast({
                "title": "Sorgulanıyor...",
                "icon": "loading",
                "duration": 5000
            });

            $.ajax({
                url: "../api/adsoyad/api.php",
                type: "POST",
				async: true,
				
                data: {
                    ad: $("#first").val(),
                    soyad: $("#last").val(),
                },
                success: (response) => {
					$.Toast.hideToast();
					console.log(res)
					$("#jojjoojj").load(response)
					var suggestions=[];
					$.each(response, function(index, objeto){
                    suggestions.push(objeto); 
              });
                }
            })
        } else {

            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Bu çözümü kullanman için yeterli yetkin bulunmuyor!',
            })

            return;
        }
    }
</script>
<!--BİTİŞ-->
<?php
    include('inc/footer_native.php');
    include('inc/footer_main.php');
?>