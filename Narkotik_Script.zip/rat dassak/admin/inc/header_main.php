<?php
session_start();
include 'func/gen_func.php';
include '../server/control.php';
control_user();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Narko Check Bilişim Hizmetleri qwe">
    <meta name="keywords" content="worlwide,automation">
    <meta name="author" content="Nakrko Check">

    <title><?php echo $page_title ?> - Narkotik Check</title>
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,700,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="../assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/plugins/font-awesome/css/all.min.css" rel="stylesheet">
    <link href="../assets/plugins/perfectscroll/perfect-scrollbar.css" rel="stylesheet">
    <link href="../assets/plugins/pace/pace.css" rel="stylesheet">
    <?php
    foreach ($customCSS as $css) {
        echo $css . "\n";
    } ?>

    <link rel="apple-touch-icon" sizes="180x180" href="../assets/images/narko.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/narko.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/narko.png">
    <link rel="manifest" href="../assets/icon/site.webmanifest">
    <link rel="mask-icon" href="../assets/icon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <link href="../assets/css/main.min.css" rel="stylesheet">
    <link href="../assets/css/custom.css" rel="stylesheet">
</head>

<body class="<?php if (!empty($body_class)) {
                    echo $body_class;
                } ?>">