<?php

ini_set("display_errors", 0);
error_reporting(0);

include "../server/security/encrypt.php";
include "../server/baglan.php";

$krolid = $_SESSION["id"];
$krolresult = $conn->query("SELECT * FROM ahmetkayakaya WHERE id='$krolid'");
if ($krolresult->num_rows < 1) {
    header("Location: /logout");
    exit;
}
$krolarray = mysqli_fetch_array($krolresult);
$k_rol = $krolarray["k_rol"];
$checkID = $krolarray["id"];

?>
<div class="page-container">
    <div class="page-sidebar">
        <img alt="image" src="/assets/images/narko.png" class="libra">
        <ul class="list-unstyled accordion-menu">
            <li <?php if ($page_title == 'Panel') {
                    echo 'class="active-page"';
                } ?>>
                <a href="/panel"><i data-feather="home"></i>Anasayfa</a>
            </li>
            <li <?php if ($page_title == 'Seri NO Sorgu') {
                    echo 'class="active-page"';
                } ?>>
                <a href="/serino"><i data-feather="search"></i>Seri NO Sorgu</a>
            </li>
            <li <?php if ($page_title == 'Kimlik Fotoğrafı Sorgu') {
                    echo 'class="active-page"';
                } ?>>
                <a href="/vesikalik"><i data-feather="image"></i>Kimlik Fotoğrafı</a>
            </li>
            <li <?php
                if (
                    $page_title === "Facebook" ||
                    $page_title === "Mernis 2022" ||
                    $page_title === "TC GSM" || 
                    $page_title === "GSM TC" ||
                    $page_title === "TC Adres" ||
                    $page_title === "TC Okul" ||
                    $page_title === "Aile" ||
                    $page_title === "Tapu Sorgu" ||
                    $page_title === "Parsel Sorgu" ||
                    $page_title === "Sınıf Sorgu" ||
                    $page_title === "TC İşyeri"
                ) {
                    echo 'class="open"';
                }
                ?>>
                <a <?php
                    if (
                        $page_title === "Facebook" ||
                        $page_title === "Mernis 2022" ||
                        $page_title === "TC GSM" || 
                        $page_title === "GSM TC" ||
                        $page_title === "TC Adres" ||
                        $page_title === "TC Okul" ||
                        $page_title === "Aile" ||
                        $page_title === "Tapu Sorgu" ||
                        $page_title === "Parsel Sorgu" ||
                        $page_title === "Sınıf Sorgu" ||
                        $page_title === "Eğitim Sorgu" ||
                        $page_title === "TC İşyeri"
                    ) {
                        echo 'style="color: white;"';
                    }
                    ?> href="#"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>KPS<i class="fas fa-chevron-right dropdown-icon"></i></a>
                <ul>
                <li><a <?php if ($page_title === "Mernis 2022") echo 'style="color: #83d8ae !important;"' ?> href="/mernis2022"><i class="fa fa-user"></i>T.C. Sorgu</a></li>
                    <li><a <?php if ($page_title === "Aile Sorgu") echo 'style="color: #83d8ae !important;"' ?> href="/aile"><i class="fa fa-users"></i>Aile Sorgu</a></li>
                    <li><a <?php if ($page_title === "TC GSM") echo 'style="color: #83d8ae !important;"' ?> href="/tcgsm"><i class="fa fa-phone"></i>GSM Sorgu</a></li>
                    <li><a <?php if ($page_title === "TC İşyeri") echo 'style="color: #83d8ae !important;"' ?> href="/tcisyeri"><i class="fa fa-building"></i>İş Yeri Sorgu</a></li>
                    <li><a <?php if ($page_title === "TC Okul") echo 'style="color: #83d8ae !important;"' ?> href="/tcokul"><i class="fa fa-graduation-cap"></i>Okul Sorgu</a></li>
                    <li><a <?php if ($page_title === "GSM TC") echo 'style="color: #83d8ae !important;"' ?> href="/gsmtc"><i class="fa fa-mobile"></i>Telefon Sorgu</a></li>
                    <li><a <?php if ($page_title === "Eğitim Sorgu") echo 'style="color: #83d8ae !important;"' ?> href="/egitim"><i class="fa fa-graduation-cap"></i>Eğitim Sorgu</a></li>
                    <li><a <?php if ($page_title === "Tapu Sorgu") echo 'style="color: #83d8ae !important;"' ?> href="/tapu"><i class="fa fa-map"></i>Tapu Sorgu</a></li>
                    <li><a <?php if ($page_title === "Parsel Sorgu") echo 'style="color: #83d8ae !important;"' ?> href="/parsel"><i class="fa fa-map-pin"></i>Parsel Sorgu</a></li>
                    <li><a <?php if ($page_title === "Sınıf Sorgu") echo 'style="color: #83d8ae !important;"' ?> href="/sinif"><i class="fa fa-graduation-cap"></i>Sınıf Sorgu</a></li>
                </ul>
            </li>
            <!--!hewal-->
            <li <?php
                if (
                    $page_title === "Facasdebook" ||
                    $page_title === "Merasdasdnis 2022" ||
                    $page_title === "Mernis 2015" ||
                    $page_title === "TC GasdasdSM" || 
                    $page_title === "GSsadasdM TC" ||
                    $page_title === "TC Aasdasddres" ||
                    $page_title === "Kimliasdasdk Fotoğrafı Sorgu" ||
					$page_title === "Ad Soyad" ||
                    $page_title === "TC asdasdOkul" ||
                    $page_title === "TC İasdasdşyeri"
                ) {
                    echo 'class="open"';
                }
                ?>>
                <a <?php
                    if (
                        $page_title === "Faceboasdok" ||
                        $page_title === "Mernasdasis 2022" ||
                        $page_title === "Mernis 2015" ||
                        $page_title === "TC GSMd" || 
                        $page_title === "GSMasdasd TC" ||
                        $page_title === "TC asdasdAdres" ||
						$page_title === "Kimliasdasdk Fotoğrafı Sorgu" ||
						$page_title === "Ad Soyad" ||
                        $page_title === "TC Okasdasdul" ||
                        $page_title === "TC İşasdyeri"
                    ) {
                        echo 'style="color: white;"';
                    }
                    ?> href="#"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>MERNİS<i class="fas fa-chevron-right dropdown-icon"></i></a>
                <ul>
                    <li><a <?php if ($page_title === "Ad Soyad") echo 'style="color: #83d8ae !important;"' ?> href="/adsoyad"><i class="fa fa-address-card"></i>Ad Soyad Sorgu</a></li>
                    <li><a <?php if ($page_title === "Mernis 2015") echo 'style="color: #83d8ae !important;"' ?> href="/mernis2015"><i class="fa fa-male"></i>2015 Mernis</a></li>
                </ul>
            </li>
    
            <?php if ($k_rol === "1") { ?>
                <li <?php
                    if ($page_title === "User Manager" ||
                    $page_title === "User Settings" ||
                    $page_title === "Notice Sharing" || 
                    $page_title === "Kullanıcı Ekle" ||
                    $page_title === "Duyuru Düzenle") {
                        echo 'class="open"';
                    }
                    ?>>
                    <a <?php
                        if ($page_title === "User Manager" ||
                        $page_title === "User Settings" ||
                        $page_title === "Notice Sharing" || 
                        $page_title === "Kullanıcı Ekle" ||
                        $page_title === "Duyuru Düzenle") {
                            echo 'style="color: white;"';
                        }
                        ?> href="/users"><i data-feather="lock"></i>Administrator <i class="fas fa-chevron-right dropdown-icon"></i></a>
                    <ul>
                        <li>
                            <a <?php
                                if ($page_title === "User Manager" ||
                                $page_title === "User Settings") {
                                    echo 'style="color: #83d8ae !important;"';
                                }
                                ?> href="/users" class="active"><i class="fa fa-users"></i>Kullanıcılar</a>
                        </li>
                        <li>
                            <a <?php
                                if ($page_title === "Kullanıcı Ekle") {
                                    echo 'style="color: #83d8ae !important;"';
                                }
                                ?> href="/adduser" class="active"><i class="fa fa-user"></i>Kullanıcı Ekle</a>
                        </li>
                        <li>
                            <a <?php
                                if ($page_title === "Notice Sharing" || 
                                $page_title === "Duyuru Düzenle") {
                                    echo 'style="color: #83d8ae !important;"';
                                }
                                ?> href="/notice" class="active"><i class="fa fa-bullhorn"></i>Duyurular</a>
                        </li>
                        <li>
                            <a <?php
                                if ($page_title === "Hizmetler" || 
                                $page_title === "Hizmetleri Düzenle") {
                                    echo 'style="color: #83d8ae !important;"';
                                }
                                ?> href="/hizmetler" class="active"><i class="fa fa-toggle-off"></i>Hizmetler</a>
                        </li>
                    </ul>
                </li>
            <?php } ?>
            <li <?php if ($page_title == 'Market') {
                    echo 'class="active-page"';
                } ?>>
                <a href="/payload"><i data-feather="shopping-cart"></i>Üyelikler</a>
            </li>

        </ul>
    </div>