<?php

$customCSS = array('<link href="../assets/plugins/DataTables/datatables.min.css" rel="stylesheet">');
$customJAVA = array(
    '<script src="../assets/plugins/DataTables/datatables.min.js"></script>',
    '<script src="../assets/plugins/printer/main.js"></script>',
    '<script src="../assets/js/pages/datatables.js"></script>'

);

$page_title = 'Mernis 2015';
include('inc/header_main.php');
include('inc/header_sidebar.php');
include('inc/header_native.php');
?>
<link href="../assets/css/scrollbar.css" type="text/css" rel="stylesheet"/>
<!--<div class="page-content">-->
<!--BAŞLANGIC-->
<div class="row row-sm">
            <br>
             
                

                    <div class="col-lg-14">

                  

                            <div class="card-body">
                            <br>
                           <center></center>

                                <div class="card">
                          
                                    <div class="card-body">
                                    <br>

										 <h6 style="text-transform: none;" class="card-title">AD SOYAD SORGU</h6>
										<br>
                                        <h7 style="text-transform: none;" class="card-title"> ÜNLÜ SORGU YAPMAYINIZ.</h7>
										<br>
										<br>
                                        <br>
                                        <br> 
                                        <form>
                                            <div class="form-group">
                                                <input type="text" maxlength="10" class="form-control" id="ad" placeholder="Ad Giriniz.">
                                                <br>
                                            </div>
											<div class="form-group">
                                                <input type="text" maxlength="10" class="form-control" id="soyad" placeholder="Soyad Giriniz.">
                                                <br>
                                            </div>
                                            <center>
                                                <button style="padding: 10px 90px; border-radius: 10px;" autocomplete="0" type="button" onclick="checkNumber()" class="btn btn-primary btn-icon-text">
                                                    <i class="btn-icon-prepend" data-feather="check-circle"></i>
                                                    Sorgula!
                                                </button>
                                            </center>
                                            <br>

                                    
                                        </form>

                                        <div class="table-responsive">

<table id="zero-conf" class="table table-hover" style="width:100%">
    <thead>
        <tr>
            <th>Kimlik No</th>
            <th>Adı</th>
            <th>Soyadı</th>
            <th>Cinsiyeti</th>
            <th>Ana Adı</th>
            <th>Baba Adı</th>
            <th>Doğum Yeri</th>
            <th>Doğum Tarihi</th>
            <th>Nüfus İl</th>
            <th>Nüfus İlçe</th>
            <th>Adres İl</th>
            <th>Adres Ilçe</th>
            <th>Mahalle</th>
            <th>Cadde</th>
            <th>Kapı No</th>
            <th>Daire No</th>
        </tr>
    </thead>
    <tbody id="jojjoojj">
    </tbody>
</table>
</div>
                                       
                                        <script>
                                            function checkNumber() {
                                                $.ajax({
                                                    url: "../api/2015/api.php",
                                                    type: "POST",
                                                    data: {
                                                        ad: $("#ad").val(),
														soyad: $("#soyad").val(),
                                                    },
                                                    success: (res) => {
                                                        if (res) {
                                                            var json = res;
                                                            $("#wizard").html(json)
                                                        } else {
                                                            alert("Hata oluştu!");
                                                            return;
                                                        }
                                                    },
                                                    error: () => {
                                                        alert("Hata oluştu!");
                                                    }
                                                });
                                            }
                                        </script>
                                </div>

                        </div>

                    </div>
                </div>
    </div>
<!--BİTİŞ-->
<?php
include('inc/footer_native.php');
include('inc/footer_main.php');
?>