<?php
$customCSS = array();
$customJAVA = array();

require '../server/baglan.php';
require '../server/admincontrol.php';

$page_title = 'Hizmet Yönetimi';

include('inc/header_main.php');
include('inc/header_sidebar.php');
include('inc/header_native.php');

date_default_timezone_set('Europe/Istanbul');
$nowDate = date("d.m.Y");

if (isset($_POST['sil'])) {
    $sil = htmlspecialchars($_POST['sil']);
    $query = "DELETE FROM `hizmetler` WHERE id='$sil'";
    if ($conn->query($query) === TRUE) {
        $success = 'HİZMET BAŞARIYLA SİLİNDİ';
        header('location: /hizmetler');
    } else {
        header("Location: /hizmetler");
    }
}

if (isset($_POST['icerik'])) {
    $icerik = htmlspecialchars($_POST['icerik']);
    $uzunluk = strlen($icerik);
    if ($uzunluk > "60") {
        $error = '60 Karakterden Fazla giremezsiniz!';
    }
    $queryy = "SELECT * FROM hizmetler";

    if ($result = mysqli_query($conn, $queryy)) {

        $rowcount = mysqli_num_rows($result);
        $rowcount;
    }
    if ($rowcount >= "10") {
        $error2 = '10 HİZMETTEN FAZLA GİREMEZSİN!';
    } else {
        $query = "INSERT `hizmetler` SET hizmet_icerik='$icerik',hizmet_zaman='$nowDate'";

        if ($conn->query($query) === TRUE) {
            $success = 'HİZMET BAŞARIYLA EKLENDİ';
            header('location: /hizmetler');
        } else {
            header("Location: /hizmetler");
        }
    }
}

$success2 = "";

if (isset($error)) {
    $success2 = $error;
} else {
    if (isset($error2)) {
        $success2 = $error2;
    } else {
        if (isset($success)) {
            $success2 = $success;
        } else {
            $success2 = 'HİZMET İçeriği Giriniz.';
        }
    }
}

?>
<div class="row">
    <div class="col-xl-12 col-md-6">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4"><img style="width: 30px;height: auto;" src="/assets/images/hizmetler.png" alt="">&nbsp;Hizmet Paylaşım</h4>
                    <br>
                    <div class="block-content tab-content">
                        <div class="tab-pane active" role="tabpanel">

                            <form method="post">

                                <input class="form-control" type="text" name="icerik" id="icerik" placeholder="<?php echo $success2; ?>"><br>
                        </div>

                        <center>
                            <button type="submit" class="btn waves-effect waves-light btn-rounded btn-success" style="width: 180px; height: 45px; outline: none; margin-left: 5px;"><i class="fas fa-search"></i> Paylaş </button> </form>
                        </center>
                        <br>
                        <div class="table-responsive">

                            <table id="zero-conf" class="table table-hover" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Hizmet İçeriği</th>
                                        <th>Yayın Tarihi</th>
                                        <th>Sil</th>
                                    </tr>
                                </thead>
                                <?php
                                $query = mysqli_query($conn, "SELECT * FROM `hizmetler`");
                                while ($getvar = mysqli_fetch_assoc($query)) {
                                    echo '
								<tr><td>' . $getvar['hizmet_icerik'] . '</td>
								<td>' . $getvar['hizmet_zaman'] . '</td>
								<td><form method="POST"><button class="btn btn-outline-danger type="submit" name="sil" value="' . $getvar['id'] . '">Sil</button></form></td>
								';
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</div>
<?php
include('inc/footer_native.php');
include('inc/footer_main.php');
?>

<script>
    document.addEventListener('contextmenu', event => event.preventDefault());
 //çok zekisin f12 basıp farklı bir siteden giriyorsun
    document.onkeydown = function (e) {
 
        if(e.keyCode == 123) {
            return false;
        }
 
        if(e.ctrlKey && e.shiftKey && e.keyCode == 73){
            return false;
        }
 
        if(e.ctrlKey && e.shiftKey && e.keyCode == 74) {
            return false;
        }
 
        if(e.ctrlKey && e.keyCode == 85) {
            return false;
        }
    }
 
</script>