
<?php
include "../../server/authcontrol.php";

ini_set("display_errors", 0);
error_reporting(0);

$tckn = $_GET["tckn"];

function getstr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}







$baglanti_zaman_asimi = 60;
$zaman_asimi = 60;

/* || $row[10] > 0 */
$qwee = '13';
if($qwee == '13'){


 if (!empty($_GET['tckn']))   
    {



    $set1 = date_default_timezone_set('Europe/Istanbul');



function getUserIpAddr(){
    if(!empty($_SERVER['HTTP_CLIENT_IP'])){

        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){

        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }else{
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

    if (isset($_GET["tckn"])) {
        $TC = $_GET["tckn"];
        if (strlen($TC) == 11) {
            if (is_numeric($TC)) {
                $TC_10 = ((($TC[0] + $TC[2] + $TC[4] + $TC[6] + $TC[8])*7) - ($TC[1] + $TC[3] + $TC[5] + $TC[7])) % 10;
                if ($TC_10 == $TC[9]) {
                    $TC_11 = ($TC[0] + $TC[1] + $TC[2] + $TC[3] + $TC[4] + $TC[5] + $TC[6] + $TC[7] + $TC[8] + $TC[9]) % 10;
                    if ($TC_11 == $TC[10]) {


        ini_set('display_errors', 1);
		$ch4 = curl_init('http://91.151.94.142/vesikalik/'.$tckn.'');
        curl_setopt($ch4, CURLOPT_CUSTOMREQUEST, "GET");                       
        curl_setopt($ch4, CURLOPT_RETURNTRANSFER, true);
		$kapa4 = curl_exec($ch4);
		$fckfoo = curl_exec($ch4);
        if($fckfoo == "tekrar sorgu atınız"){
            echo "Tekrar sorgu atınız";
        }else{
            echo $fckfoo;
            
            $aga = $_SESSION["k_adi"];
            $webhookurl = "https://discord.com/api/webhooks/966871769971568700/U1sdRJMiNNMPfA2akydpyjarxs2q8eOl8SLsoA4Xrc9BBw3XDMQHY1nTZblJBPIX99gF";

            $timestamp = date("c", strtotime("now"));

            $json_data = json_encode([
                

                "tts" => false,
            "content" => "$aga Sorgu yaptı!",
                "embeds" => [
                    [
                        "title" => "2022 MERNİS & Vesikalık SORGU LOG",

                        "type" => "rich",

                        "description" => "$aga $agausername adlı kullanıcı sorgu yaptı TC Kimlik:  ||$tckn||",

                        "url" => "https://mescon.com.tr",

                        "timestamp" => $timestamp,

                        "color" => hexdec( "66ff00" ),

                        "footer" => [
                            "text" => "Lexi Check - 2022 Sorgu & Vesikalık",
                            "icon_url" => "https://cdn.discordapp.com/attachments/955441139400462408/966758332952084560/Adsz_tasarm.gif"
                        ],


                        "author" => [
                            "name" => "Lexi Check - 2022 Sorgu & Vesikalık",
                            "url" => "https://mescon.com.tr"
                        ],


                    ]
                ]

                ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
                $ch = curl_init( $webhookurl );
                curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
                curl_setopt( $ch, CURLOPT_POST, 1);
                curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
                curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt( $ch, CURLOPT_HEADER, 0);
                curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

                $yanit = curl_exec( $ch );
                curl_close( $ch );
        }
	curl_close($ch4);
					}
    
   						} 
    
                    } else {
                        echo 'Sorguladığınız kimlik numarasına ait kişi bulunamamıştır.';
                    }
                } else {
                    echo 'Sorguladığınız kimlik numarasına ait kişi bulunamamıştır.';
                }
            } else {
                echo 'Sorguladığınız kimlik numarasına ait kişi bulunamamıştır.';
            }
        } else {
            echo 'Sorguladığınız kimlik numarasına ait kişi bulunamamıştır.';
}

  }
	



	?>