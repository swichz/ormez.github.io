<?php

ini_set('display_errors', 0);
error_reporting(0);

?>