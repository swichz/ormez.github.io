<?php

$ad = htmlspecialchars($_POST['ad']);
$soyad = htmlspecialchars($_POST['soyad']);

$url = "http://20.169.105.75/ferditayfurmuziklersonhd2022/2015ysk/2015ysk.php?adi=$ad&soyadi=$soyad";

$bacis1kenfayuj = curl_init($url);
curl_setopt($bacis1kenfayuj, CURLOPT_URL, $url);
curl_setopt($bacis1kenfayuj, CURLOPT_RETURNTRANSFER, true);
curl_setopt($bacis1kenfayuj, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($bacis1kenfayuj, CURLOPT_SSL_VERIFYPEER, false);

$json = curl_exec($bacis1kenfayuj);
curl_close($bacis1kenfayuj);


echo $json;
